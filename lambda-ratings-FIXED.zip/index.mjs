import { DynamoDBClient } from '@aws-sdk/client-dynamodb'
import {
  DynamoDBDocumentClient, GetCommand, PutCommand,
  DeleteCommand, QueryCommand, UpdateCommand, ScanCommand
} from '@aws-sdk/lib-dynamodb'

const ddb = DynamoDBDocumentClient.from(
  new DynamoDBClient({ region: process.env.AWS_REGION || 'ap-south-1' })
)

const RATINGS_TABLE = process.env.RATINGS_TABLE || 'cinenexa-ratings'
const REVIEWS_TABLE = process.env.REVIEWS_TABLE || 'cinenexa-reviews'

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Content-Type': 'application/json',
}

const ok      = (data, code=200) => ({ statusCode: code, headers: CORS, body: JSON.stringify({ success: true,  data  }) })
const err     = (msg,  code=500) => ({ statusCode: code, headers: CORS, body: JSON.stringify({ success: false, error: msg }) })
const getBody = (e)  => { try { return JSON.parse(e.body || '{}') } catch { return {} } }
const getAuth = (e)  =>
  e.requestContext?.authorizer?.claims?.sub ||
  e.requestContext?.authorizer?.jwt?.claims?.sub || null

// Query by movieId — tries GSI first, falls back to scan
async function getByMovieId(tableName, movieId) {
  try {
    const result = await ddb.send(new QueryCommand({
      TableName: tableName,
      IndexName: 'movieId-index',
      KeyConditionExpression: 'movieId = :mid',
      ExpressionAttributeValues: { ':mid': String(movieId) },
      ScanIndexForward: false,
      Limit: 50,
    }))
    return result.Items || []
  } catch (e) {
    // GSI not ready yet — fall back to scan with filter
    if (e.message?.includes('index')) {
      console.warn('GSI not ready, falling back to scan')
      const result = await ddb.send(new ScanCommand({
        TableName: tableName,
        FilterExpression: 'movieId = :mid',
        ExpressionAttributeValues: { ':mid': String(movieId) },
        Limit: 50,
      }))
      return result.Items || []
    }
    throw e
  }
}

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' }

  const method     = event.httpMethod
  const path       = event.path || ''
  const pathParams = event.pathParameters || {}
  const movieId    = pathParams.movieId
  const authUserId = getAuth(event)

  console.log(`${method} ${path} | movieId: ${movieId} | auth: ${authUserId}`)

  try {
    // ── GET /ratings/{movieId}/reviews ────────────────────────────────────
    if (method === 'GET' && path.includes('/reviews') && movieId) {
      const items = await getByMovieId(REVIEWS_TABLE, movieId)
      return ok(items)
    }

    // ── GET /ratings/{movieId}/summary ────────────────────────────────────
    if (method === 'GET' && path.includes('/summary') && movieId) {
      const items = await getByMovieId(RATINGS_TABLE, movieId)
      if (!items.length) return ok({ average: 0, count: 0, distribution: { 1:0,2:0,3:0,4:0,5:0 } })
      const distribution = { 1:0, 2:0, 3:0, 4:0, 5:0 }
      const total = items.reduce((sum, item) => {
        const r = Math.round(Number(item.rating))
        if (distribution[r] !== undefined) distribution[r]++
        return sum + Number(item.rating)
      }, 0)
      return ok({
        average:      Math.round((total / items.length) * 10) / 10,
        count:        items.length,
        distribution,
      })
    }

    // ── GET /ratings/{movieId}/user ───────────────────────────────────────
    if (method === 'GET' && path.includes('/user') && movieId) {
      if (!authUserId) return ok({ rating: null, review: null })
      const result = await ddb.send(new GetCommand({
        TableName: RATINGS_TABLE,
        Key: { pk: `USER#${authUserId}`, sk: `MOVIE#${movieId}` },
      }))
      if (!result.Item) return ok({ rating: null, review: null })
      const { pk, sk, ...data } = result.Item
      return ok(data)
    }

    // ── POST /ratings/{movieId}/helpful ───────────────────────────────────
    if (method === 'POST' && path.includes('/helpful') && movieId) {
      const { reviewUserId } = getBody(event)
      if (!reviewUserId) return err('reviewUserId required', 400)
      await ddb.send(new UpdateCommand({
        TableName: REVIEWS_TABLE,
        Key: { pk: `USER#${reviewUserId}`, sk: `MOVIE#${movieId}` },
        UpdateExpression: 'ADD helpful :one',
        ExpressionAttributeValues: { ':one': 1 },
      }))
      return ok({ marked: true })
    }

    // ── POST /ratings/{movieId} — submit rating + optional review ─────────
    if (method === 'POST' && movieId) {
      if (!authUserId) return err('Unauthorized', 401)
      const { rating, review, movieTitle, genres } = getBody(event)
      if (!rating || Number(rating) < 1 || Number(rating) > 5) {
        return err('Rating must be between 1 and 5', 400)
      }
      const now = new Date().toISOString()

      await ddb.send(new PutCommand({
        TableName: RATINGS_TABLE,
        Item: {
          pk:         `USER#${authUserId}`,
          sk:         `MOVIE#${movieId}`,
          userId:     authUserId,
          movieId:    String(movieId),
          rating:     Number(rating),
          movieTitle: movieTitle || '',
          genres:     genres || [],
          ratedAt:    now,
          updatedAt:  now,
        },
      }))

      if (review?.trim()) {
        await ddb.send(new PutCommand({
          TableName: REVIEWS_TABLE,
          Item: {
            pk:         `USER#${authUserId}`,
            sk:         `MOVIE#${movieId}`,
            userId:     authUserId,
            movieId:    String(movieId),
            rating:     Number(rating),
            review:     review.trim().slice(0, 1000),
            movieTitle: movieTitle || '',
            reviewedAt: now,
            updatedAt:  now,
            helpful:    0,
          },
        }))
      }

      return ok({ rated: true, rating: Number(rating), hasReview: !!review?.trim() }, 201)
    }

    // ── DELETE /ratings/{movieId} — remove rating + review ───────────────
    if (method === 'DELETE' && movieId) {
      if (!authUserId) return err('Unauthorized', 401)
      console.log(`Deleting rating for user ${authUserId} movie ${movieId}`)
      await Promise.allSettled([
        ddb.send(new DeleteCommand({
          TableName: RATINGS_TABLE,
          Key: { pk: `USER#${authUserId}`, sk: `MOVIE#${movieId}` },
        })),
        ddb.send(new DeleteCommand({
          TableName: REVIEWS_TABLE,
          Key: { pk: `USER#${authUserId}`, sk: `MOVIE#${movieId}` },
        })),
      ])
      return ok({ deleted: true })
    }

    return err(`Route not found: ${method} ${path}`, 404)
  } catch (e) {
    console.error('Ratings error:', e.message)
    return err(e.message)
  }
}

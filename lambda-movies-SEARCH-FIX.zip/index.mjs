import https from 'https'
import zlib from 'zlib'

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Content-Type': 'application/json',
}

const ok  = (data, code=200) => ({ statusCode: code, headers: CORS, body: JSON.stringify({ success: true,  data  }) })
const err = (msg,  code=500) => ({ statusCode: code, headers: CORS, body: JSON.stringify({ success: false, error: msg }) })

// ── Gzip-safe TMDB fetch ──────────────────────────────────────────────────────
function tmdb(path) {
  return new Promise((resolve, reject) => {
    const key = process.env.TMDB_API_KEY
    const sep = path.includes('?') ? '&' : '?'
    const req = https.get(
      `https://api.themoviedb.org/3${path}${sep}api_key=${key}`,
      { headers: { 'User-Agent': 'CineNexa/1.0', Accept: 'application/json', 'Accept-Encoding': 'identity' } },
      (res) => {
        let stream = res
        const enc  = res.headers['content-encoding']
        if (enc === 'gzip')    stream = res.pipe(zlib.createGunzip())
        if (enc === 'deflate') stream = res.pipe(zlib.createInflate())
        if (enc === 'br')      stream = res.pipe(zlib.createBrotliDecompress())
        let raw = ''
        stream.on('data', c => raw += c.toString())
        stream.on('end', () => {
          try {
            const parsed = JSON.parse(raw)
            if (parsed.status_code === 7) return reject(new Error('Invalid TMDB API key'))
            resolve(parsed)
          } catch (e) {
            reject(new Error(`Parse error. Response: ${raw.slice(0, 80)}`))
          }
        })
        stream.on('error', reject)
      }
    )
    req.on('error', reject)
    req.setTimeout(12000, () => { req.destroy(); reject(new Error('TMDB timeout')) })
  })
}

// ── Smart search ──────────────────────────────────────────────────────────────
// Strategy: run up to 3 TMDB searches in parallel and merge results
// 1. Direct title search (most reliable)
// 2. If < 5 results, also search with "the " prefix stripped or added
// 3. Score by title match quality + popularity
async function smartSearch(query, page = 1) {
  const q       = query.trim()
  const encoded = encodeURIComponent(q)

  // Always run primary search
  const searches = [
    tmdb(`/search/movie?query=${encoded}&page=${page}&include_adult=false`),
  ]

  // Also try without common articles for better matching
  // "avengers" → also try "the avengers"
  // "dark knight" → also try "the dark knight"
  const withThe = encodeURIComponent('the ' + q)
  const withoutThe = q.toLowerCase().startsWith('the ')
    ? encodeURIComponent(q.slice(4).trim())
    : null

  searches.push(tmdb(`/search/movie?query=${withThe}&page=1&include_adult=false`))
  if (withoutThe) {
    searches.push(tmdb(`/search/movie?query=${withoutThe}&page=1&include_adult=false`))
  }

  const results = await Promise.allSettled(searches)

  // Merge all results, deduplicate by id
  const seen    = new Set()
  const merged  = []

  results.forEach(r => {
    if (r.status !== 'fulfilled') return
    ;(r.value.results || []).forEach(movie => {
      if (!seen.has(movie.id)) {
        seen.add(movie.id)
        merged.push(movie)
      }
    })
  })

  if (merged.length === 0) return []

  // Score each result
  const qLower = q.toLowerCase()
  const scored = merged.map(movie => {
    const title  = (movie.title || '').toLowerCase()
    const year   = parseInt((movie.release_date || '2000').slice(0, 4))
    let boost    = 0

    // Title match quality
    if (title === qLower)                          boost += 200  // exact
    else if (title === 'the ' + qLower)            boost += 180  // "The Avengers" when searching "avengers"
    else if (title.startsWith(qLower))             boost += 150  // starts with query
    else if (title.includes(qLower))               boost += 100  // contains query
    else if (qLower.includes(title))               boost += 80   // query contains title
    else if (title.includes(qLower.split(' ')[0])) boost += 40   // first word match

    // Popularity (log scaled)
    const pop = Math.log10(Math.max(movie.popularity || 1, 1)) * 20

    // Slight recency boost for newer films
    const recency = year >= 2015 ? 10 : year >= 2000 ? 5 : 0

    return { ...movie, _score: boost + pop + recency }
  })

  // Sort by score, return top 20, strip internal score field
  return scored
    .sort((a, b) => b._score - a._score)
    .slice(0, 20)
    .map(({ _score, ...movie }) => movie)
}

// ── Better similar movies ─────────────────────────────────────────────────────
async function getSimilarMovies(movieId) {
  const [detailRes, similarRes] = await Promise.allSettled([
    tmdb(`/movie/${movieId}?append_to_response=keywords`),
    tmdb(`/movie/${movieId}/similar`),
  ])

  const detail  = detailRes.status  === 'fulfilled' ? detailRes.value  : null
  let   results = similarRes.status === 'fulfilled' ? (similarRes.value.results || []) : []

  // Enrich with genre-based discovery
  if (detail?.genres?.length > 0) {
    const genreIds = detail.genres.slice(0, 2).map(g => g.id).join(',')
    try {
      const disc = await tmdb(
        `/discover/movie?with_genres=${genreIds}&sort_by=vote_average.desc&vote_count.gte=200`
      )
      const existingIds = new Set(results.map(m => m.id))
      ;(disc.results || [])
        .filter(m => String(m.id) !== String(movieId))
        .forEach(m => { if (!existingIds.has(m.id)) results.push(m) })
    } catch {}
  }

  // Keyword-based discovery
  if (detail?.keywords?.keywords?.length > 0) {
    const topKw = detail.keywords.keywords.slice(0, 3).map(k => k.id).join(',')
    try {
      const kwMovies = await tmdb(`/discover/movie?with_keywords=${topKw}&sort_by=popularity.desc`)
      const existingIds = new Set(results.map(m => m.id))
      ;(kwMovies.results || [])
        .filter(m => String(m.id) !== String(movieId))
        .forEach(m => { if (!existingIds.has(m.id)) results.push(m) })
    } catch {}
  }

  // Deduplicate and limit
  const seen = new Set()
  return results.filter(m => {
    if (!m.poster_path || seen.has(m.id)) return false
    seen.add(m.id)
    return true
  }).slice(0, 20)
}

// ── Handler ───────────────────────────────────────────────────────────────────
export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' }

  const method     = event.httpMethod
  const path       = event.path || ''
  const qs         = event.queryStringParameters || {}
  const pathParams = event.pathParameters || {}

  try {
    if (method === 'GET' && path.endsWith('/trending')) {
      const d = await tmdb('/trending/movie/week')
      return ok(d.results || [])
    }
    if (method === 'GET' && path.endsWith('/top-rated')) {
      const d = await tmdb('/movie/top_rated')
      return ok(d.results || [])
    }
    if (method === 'GET' && path.endsWith('/now-playing')) {
      const d = await tmdb('/movie/now_playing')
      return ok(d.results || [])
    }
    if (method === 'GET' && path.endsWith('/upcoming')) {
      const d = await tmdb('/movie/upcoming')
      return ok(d.results || [])
    }
    if (method === 'GET' && path.endsWith('/genres')) {
      const d = await tmdb('/genre/movie/list')
      return ok(d.genres || [])
    }
    if (method === 'GET' && path.endsWith('/search')) {
      const q = qs.q || ''
      if (!q.trim()) return ok([])
      const results = await smartSearch(q, Number(qs.page) || 1)
      return ok(results)
    }
    if (method === 'GET' && path.endsWith('/genre')) {
      const d = await tmdb(
        `/discover/movie?with_genres=${qs.genreId}&sort_by=popularity.desc&page=${qs.page || 1}`
      )
      return ok(d.results || [])
    }
    if (method === 'GET' && path.includes('/similar')) {
      const id      = pathParams.id || path.split('/').slice(-2)[0]
      const results = await getSimilarMovies(id)
      return ok(results)
    }
    if (method === 'GET' && pathParams.id) {
      const d = await tmdb(
        `/movie/${pathParams.id}?append_to_response=credits,videos,similar,keywords`
      )
      return ok(d)
    }
    return err('Route not found', 404)
  } catch (e) {
    console.error('Movies error:', e.message)
    return err(e.message)
  }
}
